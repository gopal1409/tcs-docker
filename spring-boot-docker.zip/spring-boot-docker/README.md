# Related Blog Posts

* [How to Optimize Docker Images with Spring Boot](https://reflectoring.io/spring-boot-docker/)
