package io.pratik.users;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UsersignupApplication {

	public static void main(String[] args) {
		SpringApplication.run(UsersignupApplication.class, args);
	}

}
