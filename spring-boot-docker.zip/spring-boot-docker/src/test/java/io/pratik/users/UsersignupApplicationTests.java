package io.pratik.users;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UsersignupApplicationTests {

	@Test
	void contextLoads() {
	}

}
